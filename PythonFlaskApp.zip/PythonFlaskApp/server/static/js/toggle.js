$(document).ready(function () {
    //for sidebar toggle
    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });

    /*
    //for navbar
    var w = window.outerWidth;
    $('.navbar').css('width',w);
    */
});
